<div  class="footer footer-expand" style="background-color: green; height: 50px;">
<div class="text-center font-monospace" style="color: white; padding-top: 15px;">
    &copy; Fadzrill Rahman Wijaya
</div>
</div>

