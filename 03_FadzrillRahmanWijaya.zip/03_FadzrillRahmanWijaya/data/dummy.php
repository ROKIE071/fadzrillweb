<?php
 $dataproduk=
 [
    ["JaheXpress","JaheXpress terbuat dari jahe merah gula aren dan gula pasir","3000","Jahe.jpeg"],
    ["Bunga Telang","Bunga telang di seduh dengan tahan lemon dan daun mints","5000","Bunga telang.jpeg"],
    ["Lulur Kopi","lulur kopi terbuat dari oriza chyrosopogon dan Aiyxia oliviformis","4500","Lulur Kopi.jpeg"],
    ["Lulur Intan Sari","Lulur intan sari terbuat dari oriza chyrosopogon massive","3500","lulur intan.jpeg"],
    ["Lulur Intan Sari","Lulur intan sari terbuat dari oriza chyrosopogon massive","3500","lulur intan.jpeg"],
    ["Lulur Intan Sari","Lulur intan sari terbuat dari oriza chyrosopogon massive","3500","lulur intan.jpeg"],
    ["Lulur Intan Sari","Lulur intan sari terbuat dari oriza chyrosopogon massive","3500","lulur intan.jpeg"],
    ["Lulur Intan Sari","Lulur intan sari terbuat dari oriza chyrosopogon massive","3500","lulur intan.jpeg"],
    ["Lulur Intan Sari","Lulur intan sari terbuat dari oriza chyrosopogon massive","3500","lulur intan.jpeg"],
   ];

?>