<?php
    $id = $_GET["index"];  
    require "data/dummy.php";

?>



<!doctype html>
<html lang="en">
  <head>
    <title>Halaman Transaksi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <style>
        body{
            background-image: url('images/Kesehatan.jpeg');
            background-repeat: no-repeat;
            background-size: cover;

        }

        label{
            color: black;
        }
    </style>
</head>
  <body style="background-color: black; color: white;">
   
  <?
    include "footer/navbar.php";
  ?>

  <div class="contaier p-4">
    <form action="" method="POST">
        <div class="row">
            <div class="col-md-6 col-sm-12">

            <div class="container-fluid font-monospace ">

                <div class="mt-2">
                    <label for="no">No. Transaksi</label>
                    <input type="text" class="form-control" id="no" required>
                </div>

                <div class="mt-2">
                    <label for="tanggal">Tangal Transaksi</label>
                    <input type="date" class="form-control" id="tanggal" required>
                </div>

                <div class="mt-2">
                    <label for="nama">Nama Customer</label>
                    <input type="text" class="form-control" id="nama" required>
                </div>

                <div class="mt-2">
                    <label for="pilih-handphone">Pilih bubuk</label>
                    <input type="text" class="form-control alert" style="background-color: white; color: black;" id="pilih-rumah" value="<?=$dataproduk[$id][0] ?>" readonly>
                </div>

                <div class="mt-2">
                    <label for="harga">Harga</label>
                    <input type="text" class="form-control alert" style="background-color: white; color: black;" id="harga" value="<?=$dataproduk[$id][2] ?>" readonly>
                </div>

                <div class="mt-2">
                    <label for="jumlah">Jumlah</label>
                    <input type="text" class="form-control" id="jumlah"  required>
                </div>

                <div class="mt-2">
                    <button type="button" class="btn btn-info rounded rounded-5 w-100"  onclick="hitungTotal()"> Total Harga </button>
                </div>

                <div class="mt-2">
                    <label for="total-harga">Total Harga</label>
                    <input type="text" class="form-control" id="total-harga" readonly>
                </div>


                <div class="mt-2">
                    <label for="pembayaran">Pembayaran</label>
                    <input type="text" class="form-control" id="pembayaran"required>
                </div>

                <div class="mt-2">
                    <button type="button" class="btn btn-info rounded rounded-5 w-100"  onclick="hitungKembalian()">Kembalian </button>
                </div>

                <div class="mt-2">
                    <label for="kembalian">Kembalian</label>
                    <input type="text" class="form-control" id="kembalian" required>
                </div>

                <div class="mt-2">
                    <button type="button" class="btn btn-info rounded rounded-5 w-100"  onclick="simpan()">Simpan</button>
                </div>

            </div>
    
            </div>
        </div>
    </form>
  </div>
  
  <?php
        include "footer/footer.php";
   ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>



<script>
//function mengeksekusi tugas tertentu.
function hitungTotal() 
    { 
        //let menetapkan nama ke hasil penghitungan 
        // perseInt untuk mengonversi nilai menjadi (integer).

        let Harga = parseInt(document.querySelector('#harga').value); 
        let jumlah = parseInt(document.querySelector('#jumlah').value); 

                    //(h) nya kecil 
        let totalHarga = Harga * jumlah;        
                                // (J) nya terlalu besar
        
        
        document.getElementById("total-harga").value = totalHarga; 
        
    } 

    function hitungKembalian() 
    { 

          // (T) nya terlalu besar 
        let total = parseInt(document.getElementById("total-harga").value); 
        let pembayaran = parseInt(document.getElementById("pembayaran").value); 
        let kembalian = pembayaran - total; 
            document.getElementById("kembalian").value = kembalian; 
       
    } 
//function untuk mengeksekusi tugas tertentu.
    function simpan()
    {
        alert("data berhasil disimpan");
        window.location = "home.php";
    }

</script>