<!doctype html>
<html lang="en">
  <head>
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body style="background-color: white;">

  <!-- NAVBAR -->
   <?php
        include "footer/navbar.php";
   ?>

   <div class="container my-4">
        <div class="row">

            <div class="col-lg-6 font-monospace " style="color: black;">
                <h3>Selamat Datang di<br>CO KREATIF</h3>
                <p>tersedia berbagai minuman bubuk kesehatan</p>
                <a href="#properti" class="btn btn-info rounded rounded-5">Cari</a>
            </div>

            <div class="col-lg-6">
                <img src="images/banner.jpeg" alt="IMG" width="300px" height="250px">
            </div>

        </div>
   </div>

   <hr>
   <section id="properti" class="">
        <div class="container my-3 font-monospace">
            <h4 class="alert text-center rounded rounded-5" style="background-color: green; color: white;">Daftar Jenis Bubuk Kesehatan</h4>

            <div class="row">



                <?php
                
                    require "data/dummy.php";

                        //(D) nya besar dan P nya besar 
                    foreach($dataproduk as $index => $tampil) {//foreach perulangan array
                 
                    ?> 

                <div class="col-md-3 col-sm-12">
                    <div class="card rounded rounded-5 text-center">

                        <div class="card-body alert rounded rounded-5 " style="background-color: white;">
                        <!-- (l) nya ke dobel -->
                            <img src="images/<?=$tampil[3]?>" alt="IMG" class="card-img-top rounded rounded-5" height="200px">
                            <h5><?=$tampil[0]?></h5>
                            <h5><?=$tampil[1]?></h5>
                            <p><?=$tampil[2]?></p>
                            
                        </div>
                        
                        <div class="card-footer alert">
                           

                            <a href="transaksi.php?index=<?=$index ?>" class="btn btn-info w-100 rounded rounded-5 ">Pilih Bubuk</a>
                        
                        </div>
                        
                    </div>
                </div>

                <?php } ?>
            </div>

        </div>
   </section>
   <?php

        include "footer/footer.php";
   ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>
